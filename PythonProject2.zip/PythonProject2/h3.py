#연습문제 3-3
def count_vowel(s: str) -> int:

    #vowels = ['a', 'e', 'i', 'o', 'u']
    vowels=set("aeiouAEIOU")  #실행ㅇ


    return sum(1 for ch in s if ch in vowels)

if __name__ == "__main__":
    s = input("문자입력: ")
    print(count_vowel(s))