#연습문제3-1
def calc(*args, op):
    if op == '+':
        result = 0
        for num in args:
            result += num
        return result
    elif op == '*':
        result = 1
        for num in args:
            result *= num
        return result
    else:
        return ""


print(calc(1, 1, 4, op='+'))
print(calc(1, 2, op='*'))
print(calc(1, 3, op='+'))


