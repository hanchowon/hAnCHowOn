#연습문제 3-2
def min_max(numbers):
    min_value = numbers[0]
    max_value = numbers[0]

    for num in numbers:
        if num < min_value:
            min_value = num
        if num > max_value:
            max_value = num

    return min_value, max_value


numbers = list(map(int, input("숫자 입력: ").split()))

minimum, maximum = min_max(numbers)

print("min =", minimum)
print("max =", maximum)
