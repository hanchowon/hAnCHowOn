while True:
    filename = input("파일 이름: ")

    if filename == "q":
        break

    try:
        f = open(filename, "r", encoding="utf-8")
        lines = f.readlines()
        f.close()

        for i, line in enumerate(lines, 1):
            print(i, line, end="")

        savename = filename.replace(".txt", ".sav")
        f = open(savename, "w", encoding="utf-8")

        for i, line in enumerate(lines, 1):
            f.write(f"{i} {line}")

        f.close()
        break

    except FileNotFoundError:
        print("파일이 없습니다.")