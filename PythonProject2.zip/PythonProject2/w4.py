num=int(input("숫자 입력 :"))
if num%3==0:
    print("3의 배수")
else:
    print("3배수가 아님")
if num%5==0:
    print("5의 배수")
else:
    print("5배수가 아님")
if num%15==0:
    print("3과 5의 배수")
else:
    print("3과 5의 공통 배수가 아님")