n = int(input("숫자를 입력하세요: "))

if n < 2:
    print("소수가 아닙니다.")
elif n == 2:
    print("소수입니다.")
else:
    for i in range(2, n):
        if n % i == 0:
            print("소수가 아닙니다.")
            break
    else:
        print("소수입니다.")