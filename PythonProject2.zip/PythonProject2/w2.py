student = {}

while True:
    id = input("학번을 입력하세요: ")
    if id == "quit":
        break
    if id == "0":
        break
    name = input("이름을 입력하세요: ")

    if name == "None":
        break

    student[id] = name

print("현재 명단:", student)

while True:
    id = input("검색할 학번을 입력하세요: ")

    if id == "quit":
        break

    if id in student:
        print(student[id])
    else:
        print("not found!")
