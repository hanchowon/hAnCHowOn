a = [1, 0, 1]
b = [1, 1, 2]

result = a[0]*b[0] + a[1]*b[1] + a[2]*b[2]

print(f"{a} * {b} = {result}")