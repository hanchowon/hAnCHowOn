filename = input("파일 이름: ")

try:
    f = open(filename, "r", encoding="utf-8")
    lines = f.readlines()
    f.close()

    characters = 0
    words = 0

    for line in lines:
        characters += len(line.replace(" ", "").replace("\n", ""))
        words += len(line.split())

    print("characters :", characters)
    print("words      :", words)
    print("lines      :", len(lines))

except FileNotFoundError:
    print("파일ㄴㄴ")