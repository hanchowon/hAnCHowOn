'''a=3, b=4, c=5일때 (1+a/b+c)/1 계산하기'''
a=3
b=4
c=5

print("{}".format((1+a/b+c)/1))

